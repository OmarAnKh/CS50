const express = require('express')
const path = require('path')
const fs = require('fs')
require('./DB/mongoose')
const hbs = require('hbs')
const User = require('./models/users')
const auth = require('./middleware/auth')
const bodyParser = require('body-parser')
const bcryptjs = require('bcryptjs')
const userRouter = require('./routers/users')

const app = express()
const port = 3000


const publicPath = path.join(__dirname, '../public')
const viewPath = path.join(__dirname, '../templates/views')
const partialsPath = path.join(__dirname, '../templates/partials')


app.use(express.static(publicPath))
app.set('view engine', 'hbs')
app.set('views', viewPath)
hbs.registerPartials(partialsPath)


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(userRouter)

app.get('', auth, (req, res) => {
    res.render('index', {
        title: 'online-store',
        name: "dinosaur t shirt",
        src: 'img/Urban-Outfitters.jpeg'
    })
})

app.get('/cart', auth, (req, res) => {

    res.render('cart', {
        title: 'cart',
        name: "dinosaur t shirt",
        src: 'img/Urban-Outfitters.jpeg'
    })
})


app.get('/women', (req, res) => {
    res.render('women', {

    })
})
app.get('/men', (req, res) => {
    res.render('men', {

    })
})
app.get('/kids', (req, res) => {
    res.render('kids', {

    })
})
app.get('/shoes', (req, res) => {
    res.render('shoes', {

    })
})
app.listen(port, () => {
    console.log('server is up on port ' + port)
})
