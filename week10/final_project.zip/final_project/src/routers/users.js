
const express = require('express');
const User = require('../models/users'); // Fix the typo here
const auth = require('../middleware/auth');

const router = new express.Router();

router.get('/sign-in', (req, res) => {
    res.render('sign-in', {
        title: 'sign-in'
    });
});

router.get('/sign-up', (req, res) => {
    res.render('sign-up', {});
});

router.get('/some/other/endpoint', (req, res) => {
    res.send();
});

router.post('/users/login', async (req, res) => {
    try {
        const user = await User.findByCredentials(req.body.email, req.body.password);
        const token = await user.generateAuthToken();

        res.send({ user: user.getpublicProfile(), token });
    } catch (e) {
        res.status(400).send();
    }
});

router.post("/users", async (req, res) => {
    const { email, name, password, address, age } = req.body;

    try {
        const existingUser = await User.findOne({ email });

        if (existingUser) {
            return res.status(400).send({ error: "Email already in use" });
        }

        const user = new User({ email, name, password, address, age });
        const token = await user.generateAuthToken();
        await user.save();
        res.status(201).send({ user, token });
    } catch (e) {
        res.status(500).send(e);
    }
});

router.get('/users', async (req, res) => {
    try {
        const users = await User.find();
        console.log(users);
        res.send(users);
    } catch (e) {
        res.status(500).send();
    }
});

router.post('/users/logout', auth, async (req, res) => {
    try {
        req.user.tokens = req.user.tokens.filter((token) => {
            return token.token !== req.token;
        });
        await req.user.save();
        console.log("done");
        res.send();
    } catch (e) {
        res.status(500).send();
    }
});

router.get('/to-register', (req, res) => {
    res.render('to-register', {});
});

module.exports = router;