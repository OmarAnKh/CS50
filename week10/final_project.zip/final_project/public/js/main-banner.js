document.addEventListener("DOMContentLoaded", () => {
    document.querySelector("#sign-out").addEventListener('click', async (e) => {
        const token = sessionStorage.getItem("token")
        console.log(token)
        try {
            //const token = /* get the token from where it's stored in your client, e.g., localStorage or a cookie */;

            await fetch('/logout', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}` // Include the token in the request headers
                }
            });

            // Redirect or perform any client-side actions upon successful logout
            window.open('/', "_self");
        } catch (error) {
            console.error(error);
            // Handle any errors that might occur during the logout process
        }
    });
});